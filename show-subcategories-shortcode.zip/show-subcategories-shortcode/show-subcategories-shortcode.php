<?php
/**
 * Plugin Name: Show Subcategories Shortcode
 * Description: A WordPress plugin to display subcategories of the current category using a shortcode. This plugin adds a shortcode that, when used on a category page, displays a list of subcategories of the current category in a structured HTML format. Useful for better navigation and user experience.
 * Version: 1.0.0
 * Author: Webklient.cz
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit;
}

function show_subcategories_shortcode() {
    error_log('show_subcategories_shortcode called');

    if (!is_category()) {
        error_log('Not on a category page, returning empty string.');
        return '';
    }

    $current_category = get_queried_object();
    error_log('Current category retrieved: ' . print_r($current_category, true));

    if (!$current_category instanceof WP_Term) {
        error_log('Current object is not a WP_Term, returning empty string.');
        return '';
    }

    $args = array(
        'taxonomy' => 'category',
        'child_of' => $current_category->term_id,
        'hide_empty' => false,
    );
    error_log('Arguments for get_categories: ' . print_r($args, true));

    $subcategories = get_categories($args);
    error_log('Subcategories retrieved: ' . print_r($subcategories, true));

    if (empty($subcategories)) {
        error_log('No subcategories found, returning empty string.');
        return '';
    }

    ob_start();
    ?>
    <div class="show-subcategories-container">
        <div class="show-subcategories-menu">
            <nav class="show-subcategories-nav">
                <ul id="menu-<?php echo esc_attr($current_category->slug); ?>" class="show-subcategories-list">
                    <?php foreach ($subcategories as $subcategory): ?>
                        <?php
                            $subcategory_link = get_category_link($subcategory->term_id);
                            $subcategory_name = $subcategory->name;
                            $current_class = (is_category($subcategory->term_id)) ? ' current-menu-item' : '';
                            error_log('Subcategory: ' . $subcategory_name . ', Link: ' . $subcategory_link . ', Current class: ' . $current_class);
                        ?>
                        <li id="menu-item-<?php echo esc_attr($subcategory->term_id); ?>" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-<?php echo esc_attr($subcategory->term_id); ?> show-subcategories-item<?php echo esc_attr($current_class); ?>">
                            <a href="<?php echo esc_url($subcategory_link); ?>"><?php echo esc_html($subcategory_name); ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        </div>
    </div>
    <?php

    $output = ob_get_clean();
    error_log('Output generated: ' . $output);
    return $output;
}
add_shortcode('show_subcategories', 'show_subcategories_shortcode');

function show_subcategories_help_page() {
    add_theme_page(
        'Show Subcategories Shortcode Help',
        'Subcategories Shortcode',
        'manage_options',
        'show-subcategories-help',
        'show_subcategories_help_page_content'
    );
}
add_action('admin_menu', 'show_subcategories_help_page');

function show_subcategories_help_page_content() {
    ?>
    <div class="wrap">
        <h1>Show Subcategories Shortcode Help</h1>
        <p>Thank you for using the Show Subcategories Shortcode plugin by Webklient.cz.</p>
        <h2>How to Use the Shortcode</h2>
        <p>To display the subcategories of the current category, use the following shortcode on your category pages:</p>
        <pre>[show_subcategories]</pre>
        <h2>Customizing the Styles</h2>
        <p>The output of this shortcode is wrapped in the following unique classes, allowing you to easily customize the appearance with your own CSS:</p>
        <ul>
            <li><code>.show-subcategories-container</code>: The main container wrapping the entire subcategory list.</li>
            <li><code>.show-subcategories-menu</code>: The container wrapping the menu navigation.</li>
            <li><code>.show-subcategories-nav</code>: The <code>&lt;nav&gt;</code> element wrapping the list of subcategories.</li>
            <li><code>.show-subcategories-list</code>: The <code>&lt;ul&gt;</code> element containing all the subcategory items.</li>
            <li><code>.show-subcategories-item</code>: The <code>&lt;li&gt;</code> element for each subcategory.</li>
        </ul>
        <p>You can add your custom styles in your theme's stylesheet or a custom CSS plugin to style these elements to match your website's design.</p>
    </div>
    <?php
}
